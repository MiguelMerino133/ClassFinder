package ec.edu.uce.classfinder;

import ec.edu.uce.classfinder.consola.Menu;

import java.text.ParseException;

public class Main {

    public static void main(String[] args) throws ParseException {

        Menu menu = new Menu();
        menu.mostrarMenuPrincipal();


    }
}