package ec.edu.uce.classfinder.gui;

import ec.edu.uce.classfinder.modelo.Reserva;
import ec.edu.uce.classfinder.util.Validadores;
import java.util.Scanner;

public class GUIAprobarRechazarReserva {

    private Scanner entradaTeclado = new Scanner(System.in);

    public void aprobarRechazar() {
        System.out.println("\n=== APROBAR/RECHAZAR RESERVA ===");
        String idReserva;

        do {
            System.out.print("Ingrese ID de la reserva a aprobar/rechazar (formato RES-001): ");
            idReserva = entradaTeclado.nextLine();
            if (!Validadores.esIdValido(idReserva)) {
                System.out.println("Error: El ID debe tener el formato RES-001.");
            }
        } while (!Validadores.esIdValido(idReserva));

        Reserva reserva = new Reserva();
        reserva.setIdReserva(idReserva);

        String decision;
        do {
            System.out.print("¿Aprobar o Rechazar? (aprobada/rechazada): ");
            decision = entradaTeclado.nextLine().toLowerCase();
            if (!decision.equals("aprobada") && !decision.equals("rechazada")) {
                System.out.println("Error: Debe ingresar 'aprobada' o 'rechazada'.");
            }
        } while (!decision.equals("aprobada") && !decision.equals("rechazada"));

        if (decision.equals("aprobada")) {
            reserva.aprobarReserva();
            System.out.println("Reserva aprobada con éxito.");
        } else {
            reserva.rechazarReserva();
            System.out.println("Reserva rechazada con éxito.");
        }
    }
}