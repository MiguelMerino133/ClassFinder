package ec.edu.uce.classfinder.gui;

import ec.edu.uce.classfinder.util.Validadores;
import java.util.Scanner;

public class GUIConsultarEspacio {

    private Scanner entradaTeclado = new Scanner(System.in);

    public String consultar() {
        System.out.println("\n=== CONSULTAR ESPACIO ===");
        String idEspacio;

        do {
            System.out.print("Ingrese ID del espacio a consultar (formato ESP-001): ");
            idEspacio = entradaTeclado.nextLine();
            if (!Validadores.esIdValido(idEspacio)) {
                System.out.println("Error: El ID debe tener el formato ESP-001.");
            }
        } while (!Validadores.esIdValido(idEspacio));

        return idEspacio;
    }

    public void mostrarEspacio(String idEspacio) {
        // Simulación
        System.out.println("Consulta de Espacio - ID: " + idEspacio);
        System.out.println("Nombre del espacio: Edificio Civil");
        System.out.println("Capacidad: 60");
        System.out.println("Tamaño: Mediano");
    }

}
