package ec.edu.uce.classfinder.gui;

import ec.edu.uce.classfinder.util.Validadores;

import java.util.Scanner;

public class GUIConsultarLugar {

    private Scanner entradaTeclado = new Scanner(System.in);

    public String consultar() {
        System.out.println("\n=== CONSULTAR LUGAR ===");

        String idLugar;

        do {
            System.out.print("Ingrese ID del lugar a consultar (formato XXX-000, Ej: LUG-001): ");
            idLugar = entradaTeclado.nextLine();
            if (!Validadores.esIdValido(idLugar)) {
                System.out.println("Error: El ID debe tener el formato XXX-000 (Ej: LUG-001).");
            }
        } while (!Validadores.esIdValido(idLugar));

        return idLugar;
    }

    public void mostrarLugar(String idLugar) {
        System.out.println("Consulta de Lugar - ID: " + idLugar);
        System.out.println("Nombre del lugar: Edificio Civil");
        System.out.println("Descripcion: Edificio de 4 pisos de color azul");
        System.out.println("Id Universidad: UNI-001");
    }

}
