package ec.edu.uce.classfinder.gui;

import ec.edu.uce.classfinder.util.Validadores;

import java.util.Scanner;

public class GUIConsultarLugar {

    private Scanner entradaTeclado = new Scanner(System.in);

    public String consultar() {
        System.out.println("\n=== CONSULTAR LUGAR ===");
        String idLugar;

        do {
            System.out.print("Ingrese ID del lugar a consultar (formato LUG-001): ");
            idLugar = entradaTeclado.nextLine();
            if (!Validadores.esIdValido(idLugar)) {
                System.out.println("Error: El ID debe tener el formato LUG-001.");
            }
        } while (!Validadores.esIdValido(idLugar));

        return idLugar;
    }

    public void mostrarLugar(String idLugar) {
        System.out.println("Consulta de Lugar - ID: " + idLugar);
        System.out.println("Nombre del lugar: Edificio Civil");
        System.out.println("Descripción: Edificio de 4 pisos de color blanco con azul");

        System.out.println("Espacios: ");
        System.out.println("  - ESP-001: Aula 101, Capacidad: 30, Tamaño: mediano");
        System.out.println("  - ESP-002: Auditorio Principal, Capacidad: 100, Tamaño: grande");
    }

}
