package ec.edu.uce.classfinder.gui;

import ec.edu.uce.classfinder.util.Validadores;

import java.util.Scanner;

public class GUIConsultarReserva {

    private Scanner entradaTeclado = new Scanner(System.in);

    public String consultar() {
        System.out.println("\n=== CONSULTAR RESERVA ===");
        String idReserva;

        do {
            System.out.print("Ingrese ID de la reserva a aprobar (formato XXX-000, Ej: RES-001): ");
            idReserva = entradaTeclado.nextLine();
            if (!Validadores.esIdValido(idReserva)) {
                System.out.println("Error: El ID debe tener el formato XXX-000 (Ej: RES-001).");
            }
        } while (!Validadores.esIdValido(idReserva));

        return idReserva;
    }

    public void mostrarReserva(String idReserva) {
        System.out.println("Mostrando detalles de la reserva con ID: " + idReserva);
        // Aquí deberías conectar con un GestorReserva para obtener los datos reales.
        // Por ahora, simulamos la salida.
        System.out.println("Reserva ID: " + idReserva);
        System.out.println("Usuario ID: USR-001");
        System.out.println("Espacio ID: ESP-001");
        System.out.println("Fecha Inicio: 2025/05/15 10:00");
        System.out.println("Fecha Fin: 2025/05/15 11:00");
        System.out.println("Estado: pendiente");
    }

}
