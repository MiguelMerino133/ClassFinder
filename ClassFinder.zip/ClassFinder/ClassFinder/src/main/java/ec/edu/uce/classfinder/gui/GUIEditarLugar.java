package ec.edu.uce.classfinder.gui;

import ec.edu.uce.classfinder.modelo.Lugar;
import ec.edu.uce.classfinder.util.Validadores;
import java.util.Scanner;

public class GUIEditarLugar {

    private Scanner entradaTeclado = new Scanner(System.in);

    public Lugar editar() {
        System.out.println("\n=== EDITAR LUGAR ===");
        Lugar lugar = new Lugar();

        String idLugar;
        do {
            System.out.print("Ingrese ID del lugar a editar (formato LUG-001): ");
            idLugar = entradaTeclado.nextLine();
            if (!Validadores.esIdValido(idLugar)) {
                System.out.println("Error: El ID debe tener el formato LUG-001.");
            }
        } while (!Validadores.esIdValido(idLugar));
        lugar.setIdLugar(idLugar);


        String nombre;
        do {
            System.out.print("Ingrese nuevo nombre del lugar (1-75 letras y espacios): ");
            nombre = entradaTeclado.nextLine();
            if (!Validadores.esTextoValido(nombre)) {
                System.out.println("Error: El nombre debe contener solo letras y espacios.");
            }
        } while (!Validadores.esTextoValido(nombre));
        lugar.setNombre(nombre);


        String descripcion;
        do {
            System.out.print("Ingrese nueva descripción del lugar (1-75 letras y espacios): ");
            descripcion = entradaTeclado.nextLine();
            if (!Validadores.esTextoValido(descripcion)) {
                System.out.println("Error: La descripción debe contener solo letras y espacios.");
            }
        } while (!Validadores.esTextoValido(descripcion));
        lugar.setDescripcion(descripcion);


        return lugar;
    }

}
