package ec.edu.uce.classfinder.gui;
import ec.edu.uce.classfinder.modelo.Reserva;
import ec.edu.uce.classfinder.util.Validadores;
import java.util.Date;
import java.util.Scanner;

public class GUIEditarReserva {

    private Scanner entradaTeclado = new Scanner(System.in);

    public Reserva editar() {
        System.out.println("\n=== EDITAR RESERVA ===");
        Reserva reserva = new Reserva();

        // Validar ID Reserva (String)
        String idReserva;
        do {
            System.out.print("Ingrese ID de la reserva a editar (formato XXX-000, Ej: RES-001): ");
            idReserva = entradaTeclado.nextLine();
            if (!Validadores.esIdValido(idReserva)) {
                System.out.println("Error: El ID debe tener el formato XXX-000 (Ej: RES-001).");
            }
        } while (!Validadores.esIdValido(idReserva));
        reserva.setIdReserva(idReserva);

        // Validar ID Usuario (String)
        String idUsuario;
        do {
            System.out.print("Ingrese nuevo ID del usuario (formato XXX-000, Ej: USR-001): ");
            idUsuario = entradaTeclado.nextLine();
            if (!Validadores.esIdValido(idUsuario)) {
                System.out.println("Error: El ID debe tener el formato XXX-000 (Ej: USR-001).");
            }
        } while (!Validadores.esIdValido(idUsuario));
        reserva.setIdUsuario(idUsuario);

        // Validar ID Espacio (String)
        String idEspacio;
        do {
            System.out.print("Ingrese nuevo ID del espacio (formato XXX-000, Ej: ESP-001): ");
            idEspacio = entradaTeclado.nextLine();
            if (!Validadores.esIdValido(idEspacio)) {
                System.out.println("Error: El ID debe tener el formato XXX-000 (Ej: ESP-001).");
            }
        } while (!Validadores.esIdValido(idEspacio));
        reserva.setIdEspacio(idEspacio);

        // Validar Fecha Inicio (String y transformar a Date)
        String fechaInicioStr;
        do {
            System.out.print("Ingrese nueva fecha de inicio (formato YYYY/MM/DD HH:MM, Ej: 2025/05/12 13:00): ");
            fechaInicioStr = entradaTeclado.nextLine();
            if (!Validadores.esFechaConHoraValida(fechaInicioStr)) {
                System.out.println("Error: La fecha debe tener el formato YYYY/MM/DD HH:MM y ser futura.");
            }
        } while (!Validadores.esFechaConHoraValida(fechaInicioStr));
        reserva.setFechaInicio(fechaInicioStr);

        String fechaFinStr;
        do {
            System.out.print("Ingrese nueva fecha de fin (formato YYYY/MM/DD HH:MM, Ej: 2025/05/12 15:00): ");
            fechaFinStr = entradaTeclado.nextLine();
            if (!Validadores.esFechaConHoraValida(fechaFinStr) || !Validadores.esFechaFinValida(fechaInicioStr, fechaFinStr)) {
                System.out.println("Error: La fecha de fin debe tener el formato YYYY/MM/DD HH:MM, ser futura y posterior a la fecha de inicio.");
            }
        } while (!Validadores.esFechaConHoraValida(fechaFinStr) || !Validadores.esFechaFinValida(fechaInicioStr, fechaFinStr));
        reserva.setFechaFin(fechaFinStr);

        String estado;
        do {
            System.out.print("Ingrese nuevo estado (pendiente/aprobada/rechazada/cancelada): ");
            estado = entradaTeclado.nextLine();
            if (!Validadores.esEstadoValido(estado)) {
                System.out.println("Error: El estado debe ser pendiente, aprobada, rechazada o cancelada.");
            }
        } while (!Validadores.esEstadoValido(estado));
        reserva.setEstado(estado);

        return reserva;
    }
}
