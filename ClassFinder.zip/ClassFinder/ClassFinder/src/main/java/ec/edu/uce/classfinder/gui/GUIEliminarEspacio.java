package ec.edu.uce.classfinder.gui;

import java.util.Scanner;

public class GUIEliminarEspacio {

    private Scanner entradaTeclado = new Scanner(System.in);

    public String eliminar() {
        System.out.println("\n=== ELIMINAR ESPACIO ===");
        System.out.print("Ingrese ID del espacio a eliminar (formato LUG-001): ");
        return entradaTeclado.nextLine();
    }

}
