package ec.edu.uce.classfinder.gui;

import ec.edu.uce.classfinder.util.Validadores;

import java.util.Scanner;

public class GUIEliminarLugar {

    private Scanner entradaTeclado = new Scanner(System.in);

    public String eliminar() {
        System.out.println("\n=== ELIMINAR LUGAR ===");

        String idLugar;


        do {
            System.out.print("Ingrese ID del lugar a eliminar (formato XXX-000, Ej: LUG-001): ");
            idLugar = entradaTeclado.nextLine();
            if (!Validadores.esIdValido(idLugar)) {
                System.out.println("Error: El ID debe tener el formato XXX-000 (Ej: LUG-001).");
            }
        } while (!Validadores.esIdValido(idLugar));

        return idLugar;
    }

}
