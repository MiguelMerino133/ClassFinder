package ec.edu.uce.classfinder.gui;

import ec.edu.uce.classfinder.util.Validadores;

import java.util.Scanner;

public class GUIEliminarReserva {

    private Scanner entradaTeclado = new Scanner(System.in);

    public String cancelar() {
        System.out.println("\n=== ELIMINAR RESERVA ===");
        String idReserva;


        do {
            System.out.print("Ingrese ID de la reserva a eliminar (formato RES-001): ");
            idReserva = entradaTeclado.nextLine();
            if (!Validadores.esIdValido(idReserva)) {
                System.out.println("Error: El ID debe tener el formato RES-001.");
            }
        } while (!Validadores.esIdValido(idReserva));

        return idReserva;
    }

}
