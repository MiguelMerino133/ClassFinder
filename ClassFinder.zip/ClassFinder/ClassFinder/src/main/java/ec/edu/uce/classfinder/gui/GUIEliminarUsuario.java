package ec.edu.uce.classfinder.gui;

import ec.edu.uce.classfinder.util.Validadores;

import java.util.Scanner;

public class GUIEliminarUsuario {

    private Scanner entradaTeclado = new Scanner(System.in);

    public String eliminar() {
        System.out.println("\n=== ELIMINAR USUARIO ===");
        String idUsuario;

        do {
            System.out.print("Ingrese ID del usuario a eliminar (formato XXX-000, Ej: USR-001): ");
            idUsuario = entradaTeclado.nextLine();
            if (!Validadores.esIdValido(idUsuario)) {
                System.out.println("Error: El ID debe tener el formato XXX-000 (Ej: USR-001).");
            }
        } while (!Validadores.esIdValido(idUsuario));

        return idUsuario;
    }


}
