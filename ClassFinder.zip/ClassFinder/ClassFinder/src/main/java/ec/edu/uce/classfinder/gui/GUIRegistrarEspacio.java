package ec.edu.uce.classfinder.gui;

import ec.edu.uce.classfinder.modelo.Espacio;
import ec.edu.uce.classfinder.util.Validadores;

import java.util.Scanner;

public class GUIRegistrarEspacio {

    private Scanner entradaTeclado = new Scanner(System.in);

    public Espacio registrar() {
        System.out.println("\n=== REGISTRAR ESPACIO ===");
        Espacio espacio = new Espacio();

        String idEspacio;
        do {
            System.out.print("Ingrese ID del espacio (formato XXX-000, Ej: ESP-001): ");
            idEspacio = entradaTeclado.nextLine();
            if (!Validadores.esIdValido(idEspacio)) {
                System.out.println("Error: El ID debe tener el formato XXX-000 (Ej: ESP-001).");
            }
        } while (!Validadores.esIdValido(idEspacio));
        espacio.setIdEspacio(idEspacio);


        String idLugar;
        do {
            System.out.print("Ingrese ID del lugar (formato XXX-000, Ej: LUG-001): ");
            idLugar = entradaTeclado.nextLine();
            if (!Validadores.esIdValido(idLugar)) {
                System.out.println("Error: El ID debe tener el formato XXX-000 (Ej: LUG-001).");
            }
        } while (!Validadores.esIdValido(idLugar));
        espacio.setIdLugar(idLugar);


        String nombre;
        do {
            System.out.print("Ingrese nombre del espacio (1-25 letras y espacios): ");
            nombre = entradaTeclado.nextLine();
            if (!Validadores.esTextoValido(nombre)) {
                System.out.println("Error: El nombre debe contener solo letras y espacios (1-25 caracteres).");
            }
        } while (!Validadores.esTextoValido(nombre));
        espacio.setNombre(nombre);


        String capacidadStr;
        int capacidad;
        do {
            System.out.print("Ingrese capacidad (1-999): ");
            capacidadStr = entradaTeclado.nextLine();
            if (!Validadores.esCapacidadValido(capacidadStr)) {
                System.out.println("Error: La capacidad debe ser un número entre 1 y 999.");
            }
        } while (!Validadores.esCapacidadValido(capacidadStr));
        capacidad = Integer.parseInt(capacidadStr);
        espacio.setCapacidad(capacidad);


        String tamano;
        do {
            System.out.print("Ingrese tamaño (pequeño/mediano/grande): ");
            tamano = entradaTeclado.nextLine();
            if (!Validadores.esTamanoValido(tamano)) {
                System.out.println("Error: El tamaño debe ser pequeño, mediano o grande.");
            }
        } while (!Validadores.esTamanoValido(tamano));
        espacio.setTamano(tamano);

        return espacio;
    }

}
