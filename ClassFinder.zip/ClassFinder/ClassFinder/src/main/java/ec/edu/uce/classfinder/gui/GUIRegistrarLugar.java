package ec.edu.uce.classfinder.gui;

import ec.edu.uce.classfinder.modelo.Lugar;
import ec.edu.uce.classfinder.util.Validadores;

import java.util.Scanner;

public class GUIRegistrarLugar {

    private Scanner entradaTeclado = new Scanner(System.in);

    public Lugar registrar() {
        System.out.println("\n=== REGISTRAR LUGAR ===");
        Lugar lugar = new Lugar();

        String idLugar;
        do {
            System.out.print("Ingrese ID del lugar (formato LUG-001): ");
            idLugar = entradaTeclado.nextLine();
            if (!Validadores.esIdValido(idLugar)) {
                System.out.println("Error: El ID debe tener el formato LUG-001).");
            }
        } while (!Validadores.esIdValido(idLugar));
        lugar.setIdLugar(idLugar);


        String nombre;
        do {
            System.out.print("Ingrese nombre del lugar (1-75 letras y espacios): ");
            nombre = entradaTeclado.nextLine();
            if (!Validadores.esTextoValido(nombre)) {
                System.out.println("Error: El nombre debe contener solo letras y espacios (1-75 caracteres).");
            }
        } while (!Validadores.esTextoValido(nombre));
        lugar.setNombre(nombre);


        String descripcion;
        do {
            System.out.print("Ingrese descripción del lugar (1-75 letras y espacios): ");
            descripcion = entradaTeclado.nextLine();
            if (!Validadores.esTextoValido(descripcion)) {
                System.out.println("Error: La descripción debe contener solo letras y espacios (1-75 caracteres).");
            }
        } while (!Validadores.esTextoValido(descripcion));
        lugar.setDescripcion(descripcion);


        return lugar;
    }

}
