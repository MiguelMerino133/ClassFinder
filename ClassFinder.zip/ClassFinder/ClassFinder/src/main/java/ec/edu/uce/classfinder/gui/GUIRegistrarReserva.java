package ec.edu.uce.classfinder.gui;
import ec.edu.uce.classfinder.modelo.*;
import ec.edu.uce.classfinder.util.Validadores;
import java.util.Scanner;


public class GUIRegistrarReserva {

    private Scanner entradaTeclado = new Scanner(System.in);

    public Reserva registrar() {
        System.out.println("\n=== REGISTRAR RESERVA ===");
        Reserva reserva = new Reserva();


        String idReserva;
        do {
            System.out.print("Ingrese ID de la reserva (formato RES-001): ");
            idReserva = entradaTeclado.nextLine();
            if (!Validadores.esIdValido(idReserva)) {
                System.out.println("Error: El ID debe tener el formato RES-001.");
            }
        } while (!Validadores.esIdValido(idReserva));
        reserva.setIdReserva(idReserva);


        String idUsuario;
        do {
            System.out.print("Ingrese ID del usuario (formato USR-001): ");
            idUsuario = entradaTeclado.nextLine();
            if (!Validadores.esIdValido(idUsuario)) {
                System.out.println("Error: El ID debe tener el formato USR-001.");
            }
        } while (!Validadores.esIdValido(idUsuario));
        Usuario usuario = new Usuario();
        usuario.setIdUsuario(idUsuario);
        reserva.setUsuario(usuario);


        String idEspacio;
        do {
            System.out.print("Ingrese ID del espacio (formato ESP-001: ");
            idEspacio = entradaTeclado.nextLine();
            if (!Validadores.esIdValido(idEspacio)) {
                System.out.println("Error: El ID debe tener el formato ESP-001.");
            }
        } while (!Validadores.esIdValido(idEspacio));
        Espacio espacio = new Espacio();
        espacio.setIdEspacio(idEspacio);
        reserva.setEspacio(espacio);


        String fechaInicioStr;
        do {
            System.out.print("Ingrese fecha de inicio (formato 2025/05/12 13:00): ");
            fechaInicioStr = entradaTeclado.nextLine();
            if (!Validadores.esFechaConHoraValida(fechaInicioStr)) {
                System.out.println("Error: La fecha debe tener el formato 2025/05/12 13:00 y ser futura.");
            }
        } while (!Validadores.esFechaConHoraValida(fechaInicioStr));
        reserva.setFechaInicio(fechaInicioStr);


        String fechaFinStr;
        do {
            System.out.print("Ingrese fecha de fin (formato 2025/05/12 15:00): ");
            fechaFinStr = entradaTeclado.nextLine();
            if (!Validadores.esFechaConHoraValida(fechaFinStr) || !Validadores.esFechaFinValida(fechaInicioStr, fechaFinStr)) {
                System.out.println("Error: La fecha de fin debe tener el formato 2025/05/12 15:00, ser futura y posterior a la fecha de inicio.");
            }
        } while (!Validadores.esFechaConHoraValida(fechaFinStr) || !Validadores.esFechaFinValida(fechaInicioStr, fechaFinStr));

        reserva.setFechaFin(fechaFinStr);


        reserva.setEstado("pendiente");

        return reserva;
    }

}
