package ec.edu.uce.classfinder.gui;
import ec.edu.uce.classfinder.modelo.Usuario;
import ec.edu.uce.classfinder.util.Validadores;
import java.util.Scanner;

public class GUIRegistrarUsuario {

    private Scanner entradaTeclado = new Scanner(System.in);

    public Usuario registrar() {
        System.out.println("\n=== REGISTRAR USUARIO ===");
        Usuario usuario = new Usuario();

        String idUsuario;
        do {
            System.out.print("Ingrese ID del usuario (formato XXX-000, Ej: USR-001): ");
            idUsuario = entradaTeclado.nextLine();
            if (!Validadores.esIdValido(idUsuario)) {
                System.out.println("Error: El ID debe tener el formato XXX-000 (Ej: USR-001).");
            }
        } while (!Validadores.esIdValido(idUsuario));
        usuario.setIdUsuario(idUsuario);

        String nombre;
        do {
            System.out.print("Ingrese nombre (1-25 letras y espacios): ");
            nombre = entradaTeclado.nextLine();
            if (!Validadores.esTextoValido(nombre)) {
                System.out.println("Error: El nombre debe contener solo letras y espacios (1-25 caracteres).");
            }
        } while (!Validadores.esTextoValido(nombre));
        usuario.setNombre(nombre);

        String contrasena;
        do {
            System.out.print("Ingrese contraseña (6-20 caracteres, letras, números y .@-_!%): ");
            contrasena = entradaTeclado.nextLine();
            if (!Validadores.esContrasenaValida(contrasena)) {
                System.out.println("Error: La contraseña debe tener entre 6 y 20 caracteres y contener solo letras, números y .@-_!%.");
            }
        } while (!Validadores.esContrasenaValida(contrasena));
        usuario.setContrasena(contrasena);

        String cedula;
        do {
            System.out.print("Ingrese cédula de identidad (10 dígitos): ");
            cedula = entradaTeclado.nextLine();
            if (!Validadores.esCedulaValida(cedula)) {
                System.out.println("Error: La cédula debe contener exactamente 10 dígitos.");
            }
        } while (!Validadores.esCedulaValida(cedula));
        usuario.setCedulaIdentidad(cedula);

        String correo;
        do {
            System.out.print("Ingrese correo (Ej: usuario@gmail.com, usuario@hotmail.com): ");
            correo = entradaTeclado.nextLine();
            if (!Validadores.esCorreoValido(correo)) {
                System.out.println("Error: El correo debe tener el formato usuario@dominio.com (dominio: gmail o hotmail, máximo 25 caracteres antes de @).");
            }
        } while (!Validadores.esCorreoValido(correo));
        usuario.setCorreo(correo);

        String rol;
        do {
            System.out.print("Ingrese rol (Administrador/Docente/Estudiante/Invitado): ");
            rol = entradaTeclado.nextLine();
            if (!Validadores.esRolValido(rol)) {
                System.out.println("Error: El rol debe ser Administrador, Docente, Estudiante o Invitado.");
            }
        } while (!Validadores.esRolValido(rol));
        usuario.setRol(rol);

        return usuario;
    }

}
