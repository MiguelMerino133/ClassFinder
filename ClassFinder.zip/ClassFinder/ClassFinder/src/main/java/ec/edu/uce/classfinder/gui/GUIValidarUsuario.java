package ec.edu.uce.classfinder.gui;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class GUIValidarUsuario {

    private Scanner entradaTeclado = new Scanner(System.in);

    public String[] validar() {
        System.out.println("\n=== VALIDAR CREDENCIALES ===");
        String[] credenciales = new String[2];

        boolean idValido = false;
        boolean contrasenaValida = false;


        while (!idValido) {
            System.out.print("Ingrese ID del usuario (formato USR-XXX, ej. USR-001): ");
            credenciales[0] = entradaTeclado.nextLine();


            if (credenciales[0].isEmpty()) {
                System.out.println("Error: El ID no puede estar vacío.");
            } else if (!credenciales[0].matches("USR-\\d{3}")) {
                System.out.println("Error: El ID debe seguir el formato USR-XXX (ej. USR-001).");
            } else {
                idValido = true;
            }
        }


        while (!contrasenaValida) {
            System.out.print("Ingrese contraseña (mín. 6 caracteres): ");
            credenciales[1] = entradaTeclado.nextLine();

            if (credenciales[1].isEmpty()) {
                System.out.println("Error: La contraseña no puede estar vacía.");
            } else if (credenciales[1].length() < 6) {
                System.out.println("Error: La contraseña debe tener al menos 6 caracteres.");
            } else {
                contrasenaValida = true;
            }
        }

        System.out.println("Credenciales válidas. Procediendo...");
        return credenciales;
    }




}
