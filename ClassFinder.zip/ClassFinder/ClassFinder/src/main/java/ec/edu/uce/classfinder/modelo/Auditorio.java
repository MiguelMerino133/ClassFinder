package ec.edu.uce.classfinder.modelo;

/**
 * Representa un auditorio, que es un tipo de espacio con equipo de sonido.
 * @author Miguel Merino
 */
public class Auditorio extends Espacio {

    private boolean equipoSonido;

    /**
     * Constructor por defecto.
     */
    public Auditorio() {
        super();
        equipoSonido = true;
    }

    /**
     * Constructor con parámetros.
     * @param idEspacio identificador del espacio
     * @param nombre nombre del espacio
     * @param capacidad capacidad del espacio
     * @param tamano tamaño del espacio
     * @param equipoSonido indica si tiene equipo de sonido
     */
    public Auditorio(String idEspacio, String nombre, int capacidad, String tamano, boolean equipoSonido) {
        super(idEspacio, nombre, capacidad, tamano);
        this.equipoSonido = equipoSonido;
    }

    public boolean isEquipoSonido() {
        return equipoSonido;
    }

    public void setEquipoSonido(boolean equipoSonido) {
        this.equipoSonido = equipoSonido;
    }

    public void configurarEquipo() {
        System.out.println("Configurando equipo de sonido para el auditorio: " + getNombre());
    }

    @Override
    public String toString() {
        return "Auditorio{" +
                "idEspacio='" + getIdEspacio() + '\'' +
                ", nombre='" + getNombre() + '\'' +
                ", capacidad=" + getCapacidad() +
                ", tamano='" + getTamano() + '\'' +
                ", equipoSonido=" + equipoSonido +
                '}';
    }
}
