package ec.edu.uce.classfinder.modelo;

import ec.edu.uce.classfinder.util.Validadores;

/**
 * Representa un aula, que es un tipo de espacio con un número de aula.
 * @author Miguel Merino
 */
public class Aula extends Espacio {

    private String numeroAula;

    /**
     * Constructor por defecto.
     */
    public Aula() {
        super();
        numeroAula = "A-101";
    }

    /**
     * Constructor con parámetros.
     * @param idEspacio identificador del espacio
     * @param nombre nombre del espacio
     * @param capacidad capacidad del espacio
     * @param tamano tamaño del espacio
     * @param numeroAula número del aula
     */
    public Aula(String idEspacio, String nombre, int capacidad, String tamano, String numeroAula) {
        super(idEspacio, nombre, capacidad, tamano);
        this.numeroAula = numeroAula;
    }

    public String getNumeroAula() {
        return numeroAula;
    }

    public void setNumeroAula(String numeroAula) {
        if (numeroAula == null || !Validadores.esTextoValido(numeroAula)) {
            this.numeroAula = "A-101";
        } else {
            this.numeroAula = numeroAula;
        }
    }

    public void asignarNumero() {
        System.out.println("Asignando número de aula: " + numeroAula);
    }

    @Override
    public String toString() {
        return "Aula{" +
                "idEspacio='" + getIdEspacio() + '\'' +
                ", nombre='" + getNombre() + '\'' +
                ", capacidad=" + getCapacidad() +
                ", tamano='" + getTamano() + '\'' +
                ", numeroAula='" + numeroAula + '\'' +
                '}';
    }
}