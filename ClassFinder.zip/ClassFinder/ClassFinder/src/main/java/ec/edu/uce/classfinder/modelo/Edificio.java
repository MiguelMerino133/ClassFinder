package ec.edu.uce.classfinder.modelo;

import ec.edu.uce.classfinder.util.Validadores;

/**
 * Representa un edificio, que es un tipo de lugar con número de pisos y ubicación.
 * @author Miguel Merino
 */
public class Edificio extends Lugar {

    private int numeroPisos;
    private String ubicacion;

    /**
     * Constructor por defecto.
     */
    public Edificio() {
        super();
        numeroPisos = 1;
        ubicacion = "Campus Central";
    }

    /**
     * Constructor con parámetros.
     * @param idLugar identificador del lugar
     * @param nombre nombre del lugar
     * @param descripcion descripción del lugar
     * @param numeroPisos número de pisos del edificio
     * @param ubicacion ubicación del edificio
     */
    public Edificio(String idLugar, String nombre, String descripcion, int numeroPisos, String ubicacion) {
        super(idLugar, nombre, descripcion);
        this.numeroPisos = numeroPisos;
        this.ubicacion = ubicacion;
    }

    public int getNumeroPisos() {
        return numeroPisos;
    }

    public void setNumeroPisos(int numeroPisos) {
        if (numeroPisos <= 0 || !Validadores.esNumeroValido(String.valueOf(numeroPisos))) {
            this.numeroPisos = 1;
        } else {
            this.numeroPisos = numeroPisos;
        }
    }

    public String getUbicacion() {
        return ubicacion;
    }

    public void setUbicacion(String ubicacion) {
        if (ubicacion == null || !Validadores.esTextoValido(ubicacion)) {
            this.ubicacion = "Campus Central";
        } else {
            this.ubicacion = ubicacion;
        }
    }

    public void asignarUbicacion() {
        System.out.println("Ubicación asignada: " + ubicacion);
    }

    public void agregarEdificio() {
        System.out.println("Edificio agregado: " + getNombre());
    }

    @Override
    public String toString() {
        return "Edificio{" +
                "idLugar='" + getIdLugar() + '\'' +
                ", nombre='" + getNombre() + '\'' +
                ", descripcion='" + getDescripcion() + '\'' +
                ", numeroPisos=" + numeroPisos +
                ", ubicacion='" + ubicacion + '\'' +
                '}';
    }
}