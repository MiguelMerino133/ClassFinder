package ec.edu.uce.classfinder.modelo;

import ec.edu.uce.classfinder.util.Validadores;

/**
 * Representa un espacio dentro de un lugar en la universidad.
 * @author Miguel Merino
 */
public class Espacio {

    private String idEspacio;
    private String nombre;
    private int capacidad;
    private String tamano;

    /**
     * Constructor por defecto que inicializa un espacio con valores predeterminados.
     */
    public Espacio() {
        idEspacio = "ESP-001";
        nombre = "Espacio General";
        capacidad = 10;
        tamano = "mediano";
    }

    /**
     * Constructor con parámetros.
     * @param idEspacio identificador del espacio
     * @param nombre nombre del espacio
     * @param capacidad capacidad del espacio
     * @param tamano tamaño del espacio
     */
    public Espacio(String idEspacio, String nombre, int capacidad, String tamano) {
        this.idEspacio = idEspacio;
        this.nombre = nombre;
        this.capacidad = capacidad;
        this.tamano = tamano;
    }

    public String getIdEspacio() {
        return idEspacio;
    }

    public void setIdEspacio(String idEspacio) {
        if (idEspacio == null || !Validadores.esIdValido(idEspacio)) {
            this.idEspacio = "ESP-001";
        } else {
            this.idEspacio = idEspacio;
        }
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        if (nombre == null || !Validadores.esTextoValido(nombre)) {
            this.nombre = "Espacio General";
        } else {
            this.nombre = nombre;
        }
    }

    public int getCapacidad() {
        return capacidad;
    }

    public void setCapacidad(int capacidad) {
        if (capacidad <= 0 || !Validadores.esCapacidadValido(String.valueOf(capacidad))) {
            this.capacidad = 10;
        } else {
            this.capacidad = capacidad;
        }
    }

    public String getTamano() {
        return tamano;
    }

    public void setTamano(String tamano) {
        if (tamano == null || !Validadores.esTamanoValido(tamano)) {
            this.tamano = "mediano";
        } else {
            this.tamano = tamano;
        }
    }

    public void registrarEspacio() {
        System.out.println("Espacio registrado: " + nombre);
    }

    public void actualizarCapacidad() {
        System.out.println("Capacidad actualizada para: " + nombre);
    }

    public void consultarEspacio() {
        System.out.println("Consultando espacio: " + idEspacio);
    }

    @Override
    public String toString() {
        return "Espacio{" +
                "idEspacio='" + idEspacio + '\'' +
                ", nombre='" + nombre + '\'' +
                ", capacidad=" + capacidad +
                ", tamano='" + tamano + '\'' +
                '}';
    }
}