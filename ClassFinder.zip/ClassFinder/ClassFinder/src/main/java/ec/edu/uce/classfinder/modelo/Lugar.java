package ec.edu.uce.classfinder.modelo;
import ec.edu.uce.classfinder.util.Validadores;

/**
 * Representa un lugar dentro de una universidad, que contiene espacios.
 * @author Miguel Merino
 */
public class Lugar {

    private String idLugar;
    private String nombre;
    private String descripcion;
    private Espacio[] espacios;
    private int numEspacios;

    /**
     * Constructor por defecto.
     */
    public Lugar() {
        idLugar = "LUG-001";
        nombre = "Lugar General";
        descripcion = "Descripción general";
        espacios = new Espacio[1];
        numEspacios = 0;
    }

    /**
     * Constructor con parámetros.
     * @param idLugar identificador del lugar
     * @param nombre nombre del lugar
     * @param descripcion descripción del lugar
     */
    public Lugar(String idLugar, String nombre, String descripcion) {
        this.idLugar = idLugar;
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.espacios = new Espacio[5];
        this.numEspacios = 0;
    }

    public String getIdLugar() {
        return idLugar;
    }

    public void setIdLugar(String idLugar) {
        if (idLugar == null || !Validadores.esIdValido(idLugar)) {
            this.idLugar = "LUG-001";
        } else {
            this.idLugar = idLugar;
        }
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        if (nombre == null || !Validadores.esTextoValido(nombre)) {
            this.nombre = "Lugar General";
        } else {
            this.nombre = nombre;
        }
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        if (descripcion == null || !Validadores.esTextoValido(descripcion)) {
            this.descripcion = "Descripción general";
        } else {
            this.descripcion = descripcion;
        }
    }

    public Espacio[] getEspacios() {
        return espacios;
    }

    public void setEspacios(Espacio[] espacios) {
        if (espacios == null || espacios.length > 100) {
            this.espacios = new Espacio[5];
        } else {
            this.espacios = new Espacio[espacios.length];
            System.arraycopy(espacios, 0, this.espacios, 0, espacios.length);
            this.numEspacios = Math.min(espacios.length, this.espacios.length);
        }
    }

    public int getNumEspacios() {
        return numEspacios;
    }

    public void setNumEspacios(int numEspacios) {
        if (numEspacios < 0 || numEspacios > this.espacios.length) {
            this.numEspacios = 0;
        } else {
            this.numEspacios = numEspacios;
        }
    }

    /**
     * Agrega un espacio al arreglo de espacios.
     * @param espacio espacio a agregar
     */
    public void agregarEspacio(Espacio espacio) {
        if (numEspacios == espacios.length) {
            Espacio[] temp = espacios;
            espacios = new Espacio[numEspacios + 5];
            System.arraycopy(temp, 0, espacios, 0, numEspacios);
        }
        espacios[numEspacios] = espacio;
        numEspacios++;
    }

    /**
     * Consulta todos los espacios del lugar.
     * @return cadena con la información de los espacios
     */
    public String gestionarEspacios() {
        String texto = "";
        for (int i = 0; i < numEspacios; i++) {
            texto = texto + espacios[i].toString() + "\n";
        }
        return texto;
    }

    @Override
    public String toString() {
        return "Lugar{" +
                "idLugar='" + idLugar + '\'' +
                ", nombre='" + nombre + '\'' +
                ", descripcion='" + descripcion + '\'' +
                '}';
    }
}