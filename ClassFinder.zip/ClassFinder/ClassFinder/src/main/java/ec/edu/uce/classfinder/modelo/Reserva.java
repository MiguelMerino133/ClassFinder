package ec.edu.uce.classfinder.modelo;

import ec.edu.uce.classfinder.util.Validadores;

/**
 * Representa una reserva de un espacio por parte de un usuario.
 * @author Miguel Merino
 */
public class Reserva {

    private String idReserva;
    private String fechaInicio;
    private String fechaFin;
    private String estado;
    private Usuario usuario;
    private Espacio espacio;

    /**
     * Constructor por defecto.
     */
    public Reserva() {
        idReserva = "RES-001";
        fechaInicio = "2025/05/22 10:00";
        fechaFin = "2025/05/22 12:00";
        estado = "pendiente";
        usuario = new Usuario();
        espacio = new Espacio();
    }

    /**
     * Constructor con parámetros.
     * @param idReserva identificador de la reserva
     * @param fechaInicio fecha de inicio de la reserva
     * @param fechaFin fecha de fin de la reserva
     * @param estado estado de la reserva
     * @param usuario usuario que realiza la reserva
     * @param espacio espacio reservado
     */
    public Reserva(String idReserva, String fechaInicio, String fechaFin, String estado, Usuario usuario, Espacio espacio) {
        this.idReserva = idReserva;
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
        this.estado = estado;
        this.usuario = usuario;
        this.espacio = espacio;
    }

    public String getIdReserva() {
        return idReserva;
    }

    public void setIdReserva(String idReserva) {
        if (idReserva == null || !Validadores.esIdValido(idReserva)) {
            this.idReserva = "RES-001";
        } else {
            this.idReserva = idReserva;
        }
    }

    public String getFechaInicio() {
        return fechaInicio;
    }

    public void setFechaInicio(String fechaInicio) {
        if (fechaInicio == null || !Validadores.esFechaConHoraValida(fechaInicio)) {
            this.fechaInicio = "2025/05/22 10:00";
        } else {
            this.fechaInicio = fechaInicio;
        }
    }

    public String getFechaFin() {
        return fechaFin;
    }

    public void setFechaFin(String fechaFin) {
        if (fechaFin == null || !Validadores.esFechaConHoraValida(fechaFin) || !Validadores.esFechaFinValida(this.fechaInicio, fechaFin)) {
            this.fechaFin = "2025/05/22 12:00";
        } else {
            this.fechaFin = fechaFin;
        }
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        if (estado == null || !Validadores.esEstadoValido(estado)) {
            this.estado = "pendiente";
        } else {
            this.estado = estado;
        }
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        if (usuario == null) {
            this.usuario = new Usuario();
        } else {
            this.usuario = usuario;
        }
    }

    public Espacio getEspacio() {
        return espacio;
    }

    public void setEspacio(Espacio espacio) {
        if (espacio == null) {
            this.espacio = new Espacio();
        } else {
            this.espacio = espacio;
        }
    }

    public void registrarReserva() {
        System.out.println("Reserva registrada: " + idReserva);
    }

    public void editarReserva() {
        System.out.println("Reserva editada: " + idReserva);
    }

    public void aprobarReserva() {
        this.estado = "aprobada";
        System.out.println("Reserva aprobada: " + idReserva);
    }

    public void rechazarReserva() {
        this.estado = "rechazada";
        System.out.println("Reserva rechazada: " + idReserva);
    }

    public void eliminarReserva() {
        this.estado = "cancelada";
        System.out.println("Reserva cancelada: " + idReserva);
    }

    @Override
    public String toString() {
        return "Reserva{" +
                "idReserva='" + idReserva + '\'' +
                ", fechaInicio='" + fechaInicio + '\'' +
                ", fechaFin='" + fechaFin + '\'' +
                ", estado='" + estado + '\'' +
                ", usuario=" + usuario.getIdUsuario() +
                ", espacio=" + espacio.getIdEspacio() +
                '}';
    }
}