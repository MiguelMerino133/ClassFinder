package ec.edu.uce.classfinder.modelo;

/**
 * Representa una reserva a largo plazo para un semestre.
 * @author Miguel Merino
 */
public class ReservaSemestre extends Reserva {

    private String semestre;

    /**
     * Constructor por defecto.
     */
    public ReservaSemestre() {
        super();
        semestre = "2025-1";
    }

    /**
     * Constructor con parámetros.
     * @param idReserva identificador de la reserva
     * @param fechaInicio fecha de inicio de la reserva
     * @param fechaFin fecha de fin de la reserva
     * @param estado estado de la reserva
     * @param usuario usuario que realiza la reserva
     * @param espacio espacio reservado
     * @param semestre semestre de la reserva
     */
    public ReservaSemestre(String idReserva, String fechaInicio, String fechaFin, String estado, Usuario usuario, Espacio espacio, String semestre) {
        super(idReserva, fechaInicio, fechaFin, estado, usuario, espacio);
        this.semestre = semestre;
    }

    public String getSemestre() {
        return semestre;
    }

    public void setSemestre(String semestre) {
        if (semestre == null || !semestre.matches("\\d{4}-[1-2]")) {
            this.semestre = "2025-1";
        } else {
            this.semestre = semestre;
        }
    }

    public void asignarSemestre() {
        System.out.println("Semestre asignado: " + semestre);
    }

    @Override
    public String toString() {
        return "ReservaSemestre{" +
                "idReserva='" + getIdReserva() + '\'' +
                ", fechaInicio='" + getFechaInicio() + '\'' +
                ", fechaFin='" + getFechaFin() + '\'' +
                ", estado='" + getEstado() + '\'' +
                ", usuario=" + getUsuario().getIdUsuario() +
                ", espacio=" + getEspacio().getIdEspacio() +
                ", semestre='" + semestre + '\'' +
                '}';
    }
}