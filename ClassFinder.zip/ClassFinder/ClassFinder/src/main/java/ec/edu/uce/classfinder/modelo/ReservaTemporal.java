package ec.edu.uce.classfinder.modelo;

import ec.edu.uce.classfinder.util.Validadores;

/**
 * Representa una reserva temporal por horas.
 * @author Miguel Merino
 */
public class ReservaTemporal extends Reserva {

    private int duracionHoras;

    /**
     * Constructor por defecto.
     */
    public ReservaTemporal() {
        super();
        duracionHoras = 2;
    }

    /**
     * Constructor con parámetros.
     * @param idReserva identificador de la reserva
     * @param fechaInicio fecha de inicio de la reserva
     * @param fechaFin fecha de fin de la reserva
     * @param estado estado de la reserva
     * @param usuario usuario que realiza la reserva
     * @param espacio espacio reservado
     * @param duracionHoras duración en horas de la reserva
     */
    public ReservaTemporal(String idReserva, String fechaInicio, String fechaFin, String estado, Usuario usuario, Espacio espacio, int duracionHoras) {
        super(idReserva, fechaInicio, fechaFin, estado, usuario, espacio);
        this.duracionHoras = duracionHoras;
    }

    public int getDuracionHoras() {
        return duracionHoras;
    }

    public void setDuracionHoras(int duracionHoras) {
        if (duracionHoras <= 0 || !Validadores.esNumeroValido(String.valueOf(duracionHoras))) {
            this.duracionHoras = 2;
        } else {
            this.duracionHoras = duracionHoras;
        }
    }

    public void establecerDuracion() {
        System.out.println("Duración establecida: " + duracionHoras + " horas");
    }

    public void notificarExpiracion() {
        System.out.println("Notificando expiración de la reserva: " + getIdReserva());
    }

    @Override
    public String toString() {
        return "ReservaTemporal{" +
                "idReserva='" + getIdReserva() + '\'' +
                ", fechaInicio='" + getFechaInicio() + '\'' +
                ", fechaFin='" + getFechaFin() + '\'' +
                ", estado='" + getEstado() + '\'' +
                ", usuario=" + getUsuario().getIdUsuario() +
                ", espacio=" + getEspacio().getIdEspacio() +
                ", duracionHoras=" + duracionHoras +
                '}';
    }
}