package ec.edu.uce.classfinder.modelo;

import ec.edu.uce.classfinder.util.Validadores;

/**
 * Representa una universidad.
 * @author Miguel Merino
 */
public class Universidad {

    private String idUniversidad;
    private String nombreUniversidad;
    private String nombreRector;
    private String telefono;

    /**
     * Constructor por defecto.
     */
    public Universidad() {
        idUniversidad = "UNI-001";
        nombreUniversidad = "Universidad Central";
        nombreRector = "Dr. Juan Pérez";
        telefono = "0991234567";
    }

    /**
     * Constructor con parámetros.
     * @param idUniversidad identificador de la universidad
     * @param nombreUniversidad nombre de la universidad
     * @param nombreRector nombre del rector
     * @param telefono teléfono de contacto
     */
    public Universidad(String idUniversidad, String nombreUniversidad, String nombreRector, String telefono) {
        this.idUniversidad = idUniversidad;
        this.nombreUniversidad = nombreUniversidad;
        this.nombreRector = nombreRector;
        this.telefono = telefono;
    }

    public String getIdUniversidad() {
        return idUniversidad;
    }

    public void setIdUniversidad(String idUniversidad) {
        if (idUniversidad == null || !Validadores.esIdValido(idUniversidad)) {
            this.idUniversidad = "UNI-001";
        } else {
            this.idUniversidad = idUniversidad;
        }
    }

    public String getNombreUniversidad() {
        return nombreUniversidad;
    }

    public void setNombreUniversidad(String nombreUniversidad) {
        if (nombreUniversidad == null || !Validadores.esTextoValido(nombreUniversidad)) {
            this.nombreUniversidad = "Universidad Central";
        } else {
            this.nombreUniversidad = nombreUniversidad;
        }
    }

    public String getNombreRector() {
        return nombreRector;
    }

    public void setNombreRector(String nombreRector) {
        if (nombreRector == null || !Validadores.esTextoValido(nombreRector)) {
            this.nombreRector = "Dr. Juan Pérez";
        } else {
            this.nombreRector = nombreRector;
        }
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        if (telefono == null || !telefono.matches("\\d{10}")) {
            this.telefono = "0991234567";
        } else {
            this.telefono = telefono;
        }
    }

    public void gestionarUsuario() {
        System.out.println("Gestionando usuarios...");
    }

    public void gestionarReserva() {
        System.out.println("Gestionando reservas...");
    }

    public void gestionarLugar() {
        System.out.println("Gestionando lugares...");
    }

    @Override
    public String toString() {
        return "Universidad{" +
                "idUniversidad='" + idUniversidad + '\'' +
                ", nombreUniversidad='" + nombreUniversidad + '\'' +
                ", nombreRector='" + nombreRector + '\'' +
                ", telefono='" + telefono + '\'' +
                '}';
    }
}