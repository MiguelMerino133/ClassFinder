package ec.edu.uce.classfinder.modelo;

import ec.edu.uce.classfinder.util.Validadores;

/**
 * Representa un usuario del sistema ClassFinder.
 * @author Miguel Merino
 */
public class Usuario {

    private String idUsuario;
    private String nombre;
    private String contrasena;
    private String cedulaIdentidad;
    private String correo;
    private String rol;

    /**
     * Constructor por defecto.
     */
    public Usuario() {
        idUsuario = "USR-001";
        nombre = "Miguel";
        contrasena = "123456";
        cedulaIdentidad = "1728803246";
        correo = "miguel@gmail.com";
        rol = "Estudiante";
    }

    /**
     * Constructor con parámetros.
     * @param idUsuario identificador del usuario
     * @param nombre nombre del usuario
     * @param contrasena contraseña del usuario
     * @param cedulaIdentidad cédula de identidad del usuario
     * @param correo correo electrónico del usuario
     * @param rol rol del usuario
     */
    public Usuario(String idUsuario, String nombre, String contrasena, String cedulaIdentidad, String correo, String rol) {
        this.idUsuario = idUsuario;
        this.nombre = nombre;
        this.contrasena = contrasena;
        this.cedulaIdentidad = cedulaIdentidad;
        this.correo = correo;
        this.rol = rol;
    }

    public String getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(String idUsuario) {
        if (idUsuario == null || !Validadores.esIdValido(idUsuario)) {
            this.idUsuario = "USR-001";
        } else {
            this.idUsuario = idUsuario;
        }
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        if (nombre == null || !Validadores.esTextoValido(nombre)) {
            this.nombre = "Miguel";
        } else {
            this.nombre = nombre;
        }
    }

    public String getContrasena() {
        return contrasena;
    }

    public void setContrasena(String contrasena) {
        if (contrasena == null || !Validadores.esContrasenaValida(contrasena)) {
            this.contrasena = "123456";
        } else {
            this.contrasena = contrasena;
        }
    }

    public String getCedulaIdentidad() {
        return cedulaIdentidad;
    }

    public void setCedulaIdentidad(String cedulaIdentidad) {
        if (cedulaIdentidad == null || !Validadores.esCedulaValida(cedulaIdentidad)) {
            this.cedulaIdentidad = "1728803246";
        } else {
            this.cedulaIdentidad = cedulaIdentidad;
        }
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        if (correo == null || !Validadores.esCorreoValido(correo)) {
            this.correo = "miguel@gmail.com";
        } else {
            this.correo = correo;
        }
    }

    public String getRol() {
        return rol;
    }

    public void setRol(String rol) {
        if (rol == null || !Validadores.esRolValido(rol)) {
            this.rol = "Estudiante";
        } else {
            this.rol = rol;
        }
    }

    public void registrarUsuario() {
        System.out.println("Usuario registrado: " + nombre);
    }

    public void registrarReserva() {
        System.out.println("Reserva registrada por: " + nombre);
    }

    public void consultarEspacio() {
        System.out.println("Consultando espacio...");
    }

    public void consultarLugar() {
        System.out.println("Consultando lugar...");
    }

    public void eliminarReserva() {
        System.out.println("Reserva cancelada por: " + nombre);
    }

    @Override
    public String toString() {
        return "Usuario{" +
                "idUsuario='" + idUsuario + '\'' +
                ", nombre='" + nombre + '\'' +
                ", cedulaIdentidad='" + cedulaIdentidad + '\'' +
                ", correo='" + correo + '\'' +
                ", rol='" + rol + '\'' +
                '}';
    }
}