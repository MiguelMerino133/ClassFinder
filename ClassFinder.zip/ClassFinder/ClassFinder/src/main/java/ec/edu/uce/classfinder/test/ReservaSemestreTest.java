package ec.edu.uce.classfinder.test;

import ec.edu.uce.classfinder.modelo.ReservaSemestre;

public class ReservaSemestreTest {

    public static void main(String[] args) {

        ReservaSemestre reservaSemestre = new ReservaSemestre();


        reservaSemestre.setIdReserva("RS002");
        reservaSemestre.setFechaInicio("2025/5/12 8:00");
        reservaSemestre.setFechaFin("2025/5/12 10:00");
        reservaSemestre.setEstado("aprobada");
        reservaSemestre.setIdUsuario("U002");
        reservaSemestre.setIdEspacio("E002");
        reservaSemestre.setSemestre("2025-2");


        System.out.println("ID de la reserva: " + reservaSemestre.getIdReserva());
        System.out.println("Fecha de inicio: " + reservaSemestre.getFechaInicio());
        System.out.println("Fecha de fin: " + reservaSemestre.getFechaFin());
        System.out.println("Estado: " + reservaSemestre.getEstado());
        System.out.println("ID del usuario: " + reservaSemestre.getIdUsuario());
        System.out.println("ID del espacio: " + reservaSemestre.getIdEspacio());
        System.out.println("Semestre: " + reservaSemestre.getSemestre());


        reservaSemestre.registrarReserva();
        reservaSemestre.editarReserva();
        reservaSemestre.eliminarReserva();
        reservaSemestre.asignarSemestre();
    }

}
