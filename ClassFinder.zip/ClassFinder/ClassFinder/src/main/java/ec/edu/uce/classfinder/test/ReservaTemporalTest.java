package ec.edu.uce.classfinder.test;

import ec.edu.uce.classfinder.modelo.ReservaTemporal;

public class ReservaTemporalTest {

    public static void main(String[] args) {

        ReservaTemporal reservaTemporal = new ReservaTemporal();


        reservaTemporal.setIdReserva("RT002");
        reservaTemporal.setFechaInicio("2025/5/12 12:00");
        reservaTemporal.setFechaFin("2025/5/12 14:00");
        reservaTemporal.setEstado("aprobada");
        reservaTemporal.setIdUsuario("U002");
        reservaTemporal.setIdEspacio("E002");
        reservaTemporal.setDuracionHoras(4);


        System.out.println("ID de la reserva: " + reservaTemporal.getIdReserva());
        System.out.println("Fecha de inicio: " + reservaTemporal.getFechaInicio());
        System.out.println("Fecha de fin: " + reservaTemporal.getFechaFin());
        System.out.println("Estado: " + reservaTemporal.getEstado());
        System.out.println("ID del usuario: " + reservaTemporal.getIdUsuario());
        System.out.println("ID del espacio: " + reservaTemporal.getIdEspacio());
        System.out.println("Duración en horas: " + reservaTemporal.getDuracionHoras());


        reservaTemporal.registrarReserva();
        reservaTemporal.aprobarReserva();
        reservaTemporal.eliminarReserva();
        reservaTemporal.establecerDuracion();
        reservaTemporal.notificarExpiracion();
    }

}
