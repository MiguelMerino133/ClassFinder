package ec.edu.uce.classfinder.test;
import ec.edu.uce.classfinder.modelo.Reserva;


public class ReservaTest {

    public static void main(String[] args) {

        Reserva reserva = new Reserva();


        reserva.setIdReserva("R001");
        reserva.setFechaInicio("2025/5/15 13:00");
        reserva.setFechaFin("2025/5/15 15:00");
        reserva.setEstado("pendiente");
        reserva.setIdUsuario("U002");
        reserva.setIdEspacio("E002");


        System.out.println("ID de la reserva: " + reserva.getIdReserva());
        System.out.println("Fecha de inicio: " + reserva.getFechaInicio());
        System.out.println("Fecha de fin: " + reserva.getFechaFin());
        System.out.println("Estado: " + reserva.getEstado());
        System.out.println("ID del usuario: " + reserva.getIdUsuario());
        System.out.println("ID del espacio: " + reserva.getIdEspacio());


        reserva.registrarReserva();
        reserva.editarReserva();
        reserva.eliminarReserva();
        reserva.aprobarReserva();
        reserva.rechazarReserva();

    }

}
