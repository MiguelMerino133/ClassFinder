package ec.edu.uce.classfinder.util;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

public class Validadores {

    //Validar Numeros (enteros positivos)
    public static boolean esNumeroValido(String entradaTeclado){
        Pattern pattern= Pattern.compile("^\\d+$");
        Matcher matcher= pattern.matcher(entradaTeclado);
        return matcher.matches();
    }

    //Validar caracteres (letras y espacios)
    public static boolean esTextoValido(String entradateclado){
        Pattern pattern= Pattern.compile("^[a-zA-Z\\s]{1,75}$");
        Matcher matcher= pattern.matcher(entradateclado);
        return matcher.matches();
    }

    //Validar correo electronico
    public static boolean esCorreoValido(String entradaTeclado){
        Pattern pattern= Pattern.compile("^[a-zA-Z][a-zA-Z0-9._-]{1,25}\\@(gmail|hotmail)\\.[c-o]{3}$");
        Matcher matcher = pattern.matcher(entradaTeclado);
        return matcher.matches();
    }

    //Validar ID (Ej USR-001, RES-001)
    public static boolean esIdValido(String entradaTeclado){
        Pattern pattern= Pattern.compile("^[A-Z]{3}-\\d{3}$");
        Matcher matcher= pattern.matcher(entradaTeclado);
        return matcher.matches();
    }

    //Validar fecha con hora (Año/Mes/Dia HH:MM
    public static boolean esFechaConHoraValida(String entradaTeclado){
        Pattern pattern= Pattern.compile("^\\d{4}/\\d{2}/\\d{2} \\d{2}:\\d{2}$");
        Matcher matcher= pattern.matcher(entradaTeclado);
        if (!matcher.matches())
            return false;

        try {
            SimpleDateFormat sdf= new SimpleDateFormat("yyyy/MM/dd HH:mm");
            sdf.setLenient(false);
            Date fecha= sdf.parse(entradaTeclado);
            //Verificacion que la fecha sea diferente a la establecida
            Date ahora= new Date();
            return !fecha.before(ahora);
        } catch (Exception e) {
            return false;
        }
    }

    //Validar que la fecha (hora) sea diferente a fecha de inicio
    public static boolean esFechaFinValida(String fechaInicioStr, String fechaFinStr) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm");
            sdf.setLenient(false);
            Date fechaInicio = sdf.parse(fechaInicioStr);
            Date fechaFin = sdf.parse(fechaFinStr);
            return fechaFin.after(fechaInicio);
        } catch (Exception e) {
            return false;
        }
    }

    //Validar cédula (10 digitos)
    public static boolean esCedulaValida(String entradaTeclado){
        Pattern pattern= Pattern.compile("^\\d{10}$");
        Matcher matcher= pattern.matcher(entradaTeclado);
        return matcher.matches();
    }

    //Validar Capacidad
    public static boolean esCapacidadValido(String entradaTeclado){
        Pattern pattern= Pattern.compile("^\\d{1,3}$");
        Matcher matcher= pattern.matcher(entradaTeclado);
        return matcher.matches();
    }

    //Validar Tamaño
    public static boolean esTamanoValido(String entradaTeclado){
        Pattern pattern= Pattern.compile("^(pequeño|mediano|grande)$");
        Matcher matcher= pattern.matcher(entradaTeclado.toLowerCase());
        return matcher.matches();
    }

    //Validar Estado
    public static boolean esEstadoValido(String entradaTeclado){
        Pattern pattern= Pattern.compile("^(pendiente|aprobada|rechazada|cancelada)$");
        Matcher matcher= pattern.matcher(entradaTeclado.toLowerCase());
        return matcher.matches();
    }

    //Validar Rol
    public static boolean esRolValido(String entradaTeclado){
        Pattern pattern= Pattern.compile("^(Administrador|Docente|Estudiante|Invitado)$");
        Matcher matcher= pattern.matcher(entradaTeclado);
        return matcher.matches();
    }

    //Validar contraseña
    public static boolean esContrasenaValida(String entradaTeclado){
        Pattern pattern= Pattern.compile("^[a-zA-Z0-9 .@-_!%]{6,20}$");
        Matcher matcher= pattern.matcher(entradaTeclado);
        return matcher.matches();
    }



}
