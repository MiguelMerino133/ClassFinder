package ec.edu.uce.classfinder.modelo;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class AuditorioTest {

    private Auditorio auditorio;

    @BeforeEach
    void setUp() {
        auditorio = new Auditorio();
    }

    @Test
    void isEquipoSonido() {
        auditorio.setEquipoSonido(false);
        assertTrue(auditorio.isEquipoSonido());
    }

    @Test
    void setEquipoSonido() {
        auditorio.setEquipoSonido(false);
    }

    @Test
    void configurarEquipo() {
    }

    @Test
    void testToString() {
    }
}