package ec.edu.uce.classfinder.modelo;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
class AuditorioTest {
    private Auditorio auditorio;

    @BeforeEach
    void setUp() {
        auditorio = new Auditorio("ESP-001", "LUG-001", "Auditorio Principal", 200, "grande", true);
    }

    @Test
    void isEquipoSonido() {
        assertTrue(auditorio.isEquipoSonido());

        auditorio.setEquipoSonido(false);
        assertFalse(auditorio.isEquipoSonido());
    }

    @Test
    void setEquipoSonido() {
        auditorio.setEquipoSonido(false);
        assertFalse(auditorio.isEquipoSonido());
    }

    @Test
    void configurarEquipo() {
        auditorio.configurarEquipo();
    }
}