package ec.edu.uce.classfinder.modelo;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class AulaTest {

    private Aula aula;

    @BeforeEach
    void setUp() {
        aula = new Aula();
    }

    @Test
    void getNumeroAula() {
        assertEquals("A-101", aula.getNumeroAula());
    }

    @Test
    void setNumeroAula() {
        aula.setNumeroAula("A-101");
    }

    @Test
    void asignarNumero() {
    }

    @Test
    void testToString() {
    }
}