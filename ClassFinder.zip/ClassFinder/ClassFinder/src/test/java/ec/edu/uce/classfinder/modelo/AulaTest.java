package ec.edu.uce.classfinder.modelo;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class AulaTest {
    private Aula aula;

    @BeforeEach
    void setUp() {
        aula = new Aula("ESP-002", "LUG-001", "Aula 101", 50, "mediano", "101");
    }

    @Test
    void getNumeroAula() {
        assertEquals("101", aula.getNumeroAula());

        aula.setNumeroAula("102");
        assertEquals("102", aula.getNumeroAula());
    }

    @Test
    void setNumeroAula() {
        aula.setNumeroAula("102");
        assertEquals("102", aula.getNumeroAula());
    }

    @Test
    void asignarNumero() {
        aula.asignarNumero();
    }
}