package ec.edu.uce.classfinder.modelo;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class EdificioTest {
    private Edificio edificio;

    @BeforeEach
    void setUp() {
        edificio = new Edificio("LUG-001", "Edificio A", "Edificio principal", "UNI-001", 5, "Campus Norte");
    }

    @Test
    void getNumeroPisos() {
        assertEquals(5, edificio.getNumeroPisos());

        edificio.setNumeroPisos(6);
        assertEquals(6, edificio.getNumeroPisos());
    }

    @Test
    void setNumeroPisos() {
        edificio.setNumeroPisos(6);
        assertEquals(6, edificio.getNumeroPisos());
    }

    @Test
    void getUbicacion() {
        assertEquals("Campus Norte", edificio.getUbicacion());

        edificio.setUbicacion("Campus Sur");
        assertEquals("Campus Sur", edificio.getUbicacion());
    }

    @Test
    void setUbicacion() {
        edificio.setUbicacion("Campus Sur");
        assertEquals("Campus Sur", edificio.getUbicacion());
    }

    @Test
    void asignarUbicacion() {
        edificio.asignarUbicacion();
    }

    @Test
    void agregarEdificio() {
        edificio.agregarEdificio();
    }
}