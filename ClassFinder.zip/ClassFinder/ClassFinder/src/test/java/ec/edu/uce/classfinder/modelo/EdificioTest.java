package ec.edu.uce.classfinder.modelo;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class EdificioTest {

    private Edificio edificio;

    @BeforeEach
    void setUp() {
        edificio = new Edificio();
    }

    @Test
    void getNumeroPisos() {
        edificio.setNumeroPisos(5);
        assertEquals(5, edificio.getNumeroPisos());
    }

    @Test
    void setNumeroPisos() {
        edificio.setNumeroPisos(5);
    }

    @Test
    void getUbicacion() {
        edificio.setUbicacion("Campus Norte");
        assertEquals("Campus Norte", edificio.getUbicacion());
    }

    @Test
    void setUbicacion() {
        edificio.setUbicacion("Campus Norte");
    }

    @Test
    void asignarUbicacion() {
    }

    @Test
    void agregarEdificio() {
    }

    @Test
    void testToString() {
    }
}