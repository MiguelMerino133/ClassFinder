package ec.edu.uce.classfinder.modelo;


import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class EspacioTest {

    private Espacio espacio;

    @BeforeEach
    void setUp() {
        espacio = new Espacio();
    }

    @Test
    void getIdEspacio() {
        assertEquals("ESP-001", espacio.getIdEspacio());
    }

    @Test
    void setIdEspacio() {
        espacio.setIdEspacio("ESP-002");


    }

    @Test
    void getNombre() {
        assertEquals("Espacio General", espacio.getNombre());
    }

    @Test
    void setNombre() {
        espacio.setNombre("Aula 101");
    }

    @Test
    void getCapacidad() {
        assertEquals(10, espacio.getCapacidad(), "La capacidad por defecto debe ser 10");
    }

    @Test
    void setCapacidad() {
        espacio.setCapacidad(50);

    }

    @Test
    void getTamano() {
        assertEquals("mediano", espacio.getTamano());
    }

    @Test
    void setTamano() {
        espacio.setTamano("mediano");

    }

    @Test
    void registrarEspacio() {

    }

    @Test
    void actualizarCapacidad() {

    }

    @Test
    void consultarEspacio() {

    }

    @Test
    void testToString() {
    }
}