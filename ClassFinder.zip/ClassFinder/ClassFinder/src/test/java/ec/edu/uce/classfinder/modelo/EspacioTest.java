package ec.edu.uce.classfinder.modelo;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class EspacioTest {
    private Espacio espacio;

    @BeforeEach
    void setUp() {
        espacio = new Espacio("ESP-001", "LUG-001", "Sala de Reuniones", 30, "pequeño");
    }

    @Test
    void getIdEspacio() {
        assertEquals("ESP-001", espacio.getIdEspacio());
    }

    @Test
    void setIdEspacio() {
        espacio.setIdEspacio("ESP-002");
        assertEquals("ESP-002", espacio.getIdEspacio());
    }

    @Test
    void getIdLugar() {
        assertEquals("LUG-001", espacio.getIdLugar());
    }

    @Test
    void setIdLugar() {
        espacio.setIdLugar("LUG-002");
        assertEquals("LUG-002", espacio.getIdLugar());
    }

    @Test
    void getNombre() {
        assertEquals("Sala de Reuniones", espacio.getNombre());
    }

    @Test
    void setNombre() {
        espacio.setNombre("Sala de Conferencias");
        assertEquals("Sala de Conferencias", espacio.getNombre());
    }

    @Test
    void getCapacidad() {
        assertEquals(30, espacio.getCapacidad());
    }

    @Test
    void setCapacidad() {
        espacio.setCapacidad(40);
        assertEquals(40, espacio.getCapacidad());
    }

    @Test
    void getTamano() {
        assertEquals("pequeño", espacio.getTamano());
    }

    @Test
    void setTamano() {
        espacio.setTamano("mediano");
        assertEquals("mediano", espacio.getTamano());
    }

    @Test
    void registrarEspacio() {
        espacio.registrarEspacio();
    }

    @Test
    void actualizarCapacidad() {
        espacio.actualizarCapacidad();
    }

    @Test
    void consultarEspacio() {
        espacio.consultarEspacio();
    }
}