package ec.edu.uce.classfinder.modelo;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class LugarTest {

    private Lugar lugar;

    @BeforeEach
    void setUp() {
        lugar = new Lugar();
    }

    @Test
    void getIdLugar() {
        lugar.setIdLugar("LUG-002");
        assertEquals("LUG-002", lugar.getIdLugar());
    }

    @Test
    void setIdLugar() {
        lugar.setIdLugar("LUG-002");
    }

    @Test
    void getNombre() {
        lugar.setNombre("Biblioteca");
        assertEquals("Biblioteca", lugar.getNombre());
    }

    @Test
    void setNombre() {
        lugar.setNombre("Biblioteca");
    }

    @Test
    void getDescripcion() {
        lugar.setDescripcion("Area de estudio");
        assertEquals("Area de estudio", lugar.getDescripcion());
    }

    @Test
    void setDescripcion() {
        lugar.setDescripcion("Área de estudio");
    }

    @Test
    void getEspacios() {
        assertEquals(1, lugar.getEspacios().length);
    }

    @Test
    void setEspacios() {
        Espacio[] espacios = new Espacio[1];
        lugar.setEspacios(espacios);
    }

    @Test
    void getNumEspacios() {
        Espacio espacio = new Espacio();
        lugar.agregarEspacio(espacio);
        assertEquals(1, lugar.getNumEspacios());
    }

    @Test
    void setNumEspacios() {
        lugar.setNumEspacios(1);
    }

    @Test
    void agregarEspacio() {
        Espacio espacio = new Espacio();
        lugar.agregarEspacio(espacio);
    }

    @Test
    void gestionarEspacios() {
    }

    @Test
    void testToString() {
    }
}