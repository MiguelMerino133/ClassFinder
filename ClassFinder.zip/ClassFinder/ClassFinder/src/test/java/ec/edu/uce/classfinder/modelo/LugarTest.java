package ec.edu.uce.classfinder.modelo;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
class LugarTest {
    private Lugar lugar;

    @BeforeEach
    void setUp() {
        lugar = new Lugar("LUG-001", "Edificio A", "Edificio principal", "UNI-001");
    }

    @Test
    void getIdLugar() {
        assertEquals("LUG-001", lugar.getIdLugar());
    }

    @Test
    void setIdLugar() {
        lugar.setIdLugar("LUG-002");
        assertEquals("LUG-002", lugar.getIdLugar());
    }

    @Test
    void getNombre() {
        assertEquals("Edificio A", lugar.getNombre());
    }

    @Test
    void setNombre() {
        lugar.setNombre("Edificio B");
        assertEquals("Edificio B", lugar.getNombre());
    }

    @Test
    void getDescripcion() {
        assertEquals("Edificio principal", lugar.getDescripcion());
    }

    @Test
    void setDescripcion() {
        lugar.setDescripcion("Edificio secundario");
        assertEquals("Edificio secundario", lugar.getDescripcion());
    }

    @Test
    void getIdUniversidad() {
        assertEquals("UNI-001", lugar.getIdUniversidad());
    }

    @Test
    void setIdUniversidad() {
        lugar.setIdUniversidad("UNI-002");
        assertEquals("UNI-002", lugar.getIdUniversidad());
    }

    @Test
    void registrarLugar() {
        lugar.registrarLugar();
    }

    @Test
    void modificarLugar() {
        lugar.modificarLugar();
    }

    @Test
    void eliminarLugar() {
        lugar.eliminarLugar();
    }
}