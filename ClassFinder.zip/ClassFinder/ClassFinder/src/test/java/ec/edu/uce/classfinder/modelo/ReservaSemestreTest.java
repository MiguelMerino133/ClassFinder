package ec.edu.uce.classfinder.modelo;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ReservaSemestreTest {
    private ReservaSemestre reservaSemestre;

    @BeforeEach
    void setUp(){
        reservaSemestre = new ReservaSemestre("RES-001", "2025/05/15 10:00", "2025/05/15 11:00", "pendiente", "USR-001", "ESP-001", "2025-I");
    }

    @Test
    void getSemestre() {
        assertEquals("2025-I", reservaSemestre.getSemestre());
        reservaSemestre.setSemestre("2025-II");
        assertEquals("2025-II", reservaSemestre.getSemestre());
    }

    @Test
    void setSemestre() {
        reservaSemestre.setSemestre("2025-II");
        assertEquals("2025-II", reservaSemestre.getSemestre());
    }

    @Test
    void asignarSemestre() {
        reservaSemestre.asignarSemestre();
    }
}