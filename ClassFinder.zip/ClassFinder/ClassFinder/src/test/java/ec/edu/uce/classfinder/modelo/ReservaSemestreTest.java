package ec.edu.uce.classfinder.modelo;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ReservaSemestreTest {

    private ReservaSemestre reservaSemestre;

    @BeforeEach
    void setUp() {
        reservaSemestre = new ReservaSemestre();
    }


    @Test
    void getSemestre() {
        reservaSemestre.setSemestre("2025-1");
        assertEquals("2025-1", reservaSemestre.getSemestre());
    }

    @Test
    void setSemestre() {
        reservaSemestre.setSemestre("2025-1");
    }

    @Test
    void asignarSemestre() {
    }

    @Test
    void testToString() {
    }
}