package ec.edu.uce.classfinder.modelo;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ReservaTemporalTest {
    private ReservaTemporal reservaTemporal;

    @BeforeEach
    void setUp(){
        reservaTemporal = new ReservaTemporal("RES-002", "2025/05/15 10:00", "2025/05/15 11:00", "pendiente", "USR-001", "ESP-001", 2);
    }

    @Test
    void getDuracionHoras() {
        assertEquals(2, reservaTemporal.getDuracionHoras());
        reservaTemporal.setDuracionHoras(3);
        assertEquals(3, reservaTemporal.getDuracionHoras());
    }

    @Test
    void setDuracionHoras() {
        reservaTemporal.setDuracionHoras(3);
        assertEquals(3, reservaTemporal.getDuracionHoras());
    }

    @Test
    void establecerDuracion() {
        reservaTemporal.establecerDuracion();
    }

    @Test
    void notificarExpiracion() {
        reservaTemporal.notificarExpiracion();
    }
}