package ec.edu.uce.classfinder.modelo;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ReservaTemporalTest {

    private ReservaTemporal reservaTemporal;

    @BeforeEach
    void setUp() {
        reservaTemporal = new ReservaTemporal();
    }

    @Test
    void getDuracionHoras() {
        reservaTemporal.setDuracionHoras(3);
        assertEquals(3, reservaTemporal.getDuracionHoras());
    }

    @Test
    void setDuracionHoras() {
        reservaTemporal.setDuracionHoras(3);
    }

    @Test
    void establecerDuracion() {
    }

    @Test
    void notificarExpiracion() {
    }

    @Test
    void testToString() {
    }
}