package ec.edu.uce.classfinder.modelo;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ReservaTest {

    private Reserva reserva;

    @BeforeEach
    void setUp() {
        reserva = new Reserva();
    }

    @Test
    void getIdReserva() {
        reserva.setIdReserva("RES-002");
        assertEquals("RES-002", reserva.getIdReserva());
    }

    @Test
    void setIdReserva() {
        reserva.setIdReserva("RES-002");
    }

    @Test
    void getFechaInicio() {
        reserva.setFechaInicio("2025/05/23 10:00");
        assertEquals("2025/05/23 10:00", reserva.getFechaInicio());
    }

    @Test
    void setFechaInicio() {
        reserva.setFechaInicio("2025/05/23 10:00");
    }

    @Test
    void getFechaFin() {
        reserva.setFechaFin("2025/05/23 12:00");
        assertEquals("2025/05/23 12:00", reserva.getFechaFin());
    }

    @Test
    void setFechaFin() {
        reserva.setFechaFin("2025/05/23 12:00");
    }

    @Test
    void getEstado() {
        assertEquals("pendiente", reserva.getEstado());
    }

    @Test
    void setEstado() {
        reserva.setEstado("aprobada");
    }

    @Test
    void getUsuario() {
        Usuario usuario = new Usuario();
        usuario.setIdUsuario("USR-002");
        reserva.setUsuario(usuario);
        assertEquals("USR-002", reserva.getUsuario().getIdUsuario());
    }

    @Test
    void setUsuario() {
        Usuario usuario = new Usuario();
        usuario.setIdUsuario("USR-002");
        reserva.setUsuario(usuario);
    }

    @Test
    void getEspacio() {
        Espacio espacio = new Espacio();
        espacio.setIdEspacio("ESP-002");
        reserva.setEspacio(espacio);
        assertEquals("ESP-002", reserva.getEspacio().getIdEspacio());
    }

    @Test
    void setEspacio() {
        Espacio espacio = new Espacio();
        espacio.setIdEspacio("ESP-002");
        reserva.setEspacio(espacio);
    }

    @Test
    void registrarReserva() {
    }

    @Test
    void editarReserva() {
    }

    @Test
    void aprobarReserva() {
        reserva.aprobarReserva();
        assertEquals("aprobada", reserva.getEstado());
    }

    @Test
    void rechazarReserva() {
        reserva.rechazarReserva();
        assertEquals("rechazada", reserva.getEstado());
    }

    @Test
    void eliminarReserva() {
        reserva.eliminarReserva();
        assertEquals("cancelada", reserva.getEstado());
    }

    @Test
    void testToString() {
    }
}