package ec.edu.uce.classfinder.modelo;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.Assert.assertEquals;


class ReservaTest {
    private Reserva reserva;

    @BeforeEach
    void setUp() {
        reserva = new Reserva("RES-001", "2025/05/15 10:00", "2025/05/15 11:00", "pendiente", "USR-001", "ESP-001");
    }

    @Test
    void getIdReserva() {
        assertEquals("RES-001", reserva.getIdReserva());
        reserva.setIdReserva("RES-002");
        assertEquals("RES-002", reserva.getIdReserva());
    }

    @Test
    void setIdReserva() {
        reserva.setIdReserva("RES-002");
        assertEquals("RES-002", reserva.getIdReserva());
    }

    @Test
    void getFechaInicio() {
        assertEquals("2025/05/15 10:00", reserva.getFechaInicio());
        reserva.setFechaInicio("2025/05/15 12:00");
        assertEquals("2025/05/15 12:00", reserva.getFechaInicio());
    }

    @Test
    void setFechaInicio() {
        reserva.setFechaInicio("2025/05/15 12:00");
        assertEquals("2025/05/15 12:00", reserva.getFechaInicio());
    }

    @Test
    void getFechaFin() {
        assertEquals("2025/05/15 11:00", reserva.getFechaFin());
        reserva.setFechaFin("2025/05/15 13:00");
        assertEquals("2025/05/15 13:00", reserva.getFechaFin());
    }

    @Test
    void setFechaFin() {
        reserva.setFechaFin("2025/05/15 13:00");
        assertEquals("2025/05/15 13:00", reserva.getFechaFin());
    }

    @Test
    void getEstado() {
        assertEquals("pendiente", reserva.getEstado());
        reserva.setEstado("aprobada");
        assertEquals("aprobada", reserva.getEstado());
    }

    @Test
    void setEstado() {
        reserva.setEstado("aprobada");
        assertEquals("aprobada", reserva.getEstado());
    }

    @Test
    void getIdUsuario() {
        assertEquals("USR-001", reserva.getIdUsuario());
        reserva.setIdUsuario("USR-002");
        assertEquals("USR-002", reserva.getIdUsuario());
    }

    @Test
    void setIdUsuario() {
        reserva.setIdUsuario("USR-002");
        assertEquals("USR-002", reserva.getIdUsuario());
    }

    @Test
    void getIdEspacio() {
        assertEquals("ESP-001", reserva.getIdEspacio());
        reserva.setIdEspacio("ESP-002");
        assertEquals("ESP-002", reserva.getIdEspacio());
    }

    @Test
    void setIdEspacio() {
        reserva.setIdEspacio("ESP-002");
        assertEquals("ESP-002", reserva.getIdEspacio());
    }

    @Test
    void registrarReserva() {
        reserva.registrarReserva();
    }

    @Test
    void editarReserva() {
        reserva.editarReserva();
    }

    @Test
    void eliminarReserva() {
        reserva.eliminarReserva();
    }

    @Test
    void aprobarReserva() {
        reserva.aprobarReserva();
    }

    @Test
    void rechazarReserva(){
        reserva.rechazarReserva();
    }


}