package ec.edu.uce.classfinder.modelo;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class UniversidadTest {

    private Universidad universidad;

    @BeforeEach
    void setUp() {
        universidad = new Universidad();
    }

    @Test
    void getIdUniversidad() {
        universidad.setIdUniversidad("UNI-001");
        assertEquals("UNI-001", universidad.getIdUniversidad());
    }

    @Test
    void setIdUniversidad() {
        universidad.setIdUniversidad("UNI-001");
    }

    @Test
    void getNombreUniversidad() {
        universidad.setNombreUniversidad("UCE");
        assertEquals("UCE", universidad.getNombreUniversidad());
    }

    @Test
    void setNombreUniversidad() {
        universidad.setNombreUniversidad("UCE");
    }

    @Test
    void getNombreRector() {
        universidad.setNombreRector("Dr. Juan Pérez");
        assertEquals("Dr. Juan Pérez", universidad.getNombreRector());
    }

    @Test
    void setNombreRector() {
        universidad.setNombreRector("Dr. Juan Pérez");
    }

    @Test
    void getTelefono() {
        universidad.setTelefono("0991234567");
        assertEquals("0991234567", universidad.getTelefono());
    }

    @Test
    void setTelefono() {
        universidad.setTelefono("0991234567");
    }

    @Test
    void gestionarUsuario() {
    }

    @Test
    void gestionarReserva() {
    }

    @Test
    void gestionarLugar() {
    }

    @Test
    void testToString() {
    }
}