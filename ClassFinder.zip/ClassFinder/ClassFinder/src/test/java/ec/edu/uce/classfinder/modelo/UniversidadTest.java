package ec.edu.uce.classfinder.modelo;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class UniversidadTest {
    private Universidad universidad;

    @BeforeEach
    void setUp(){
        universidad = new Universidad("UNI-001", "Universidad Central", "Dr. Juan Gomez", "1234567890");
    }

    @Test
    void getIdUniversidad() {
        assertEquals("UNI-001", universidad.getIdUniversidad());
        universidad.setIdUniversidad("UNI-002");
        assertEquals("UNI-002", universidad.getIdUniversidad());
    }

    @Test
    void setIdUniversidad() {
        universidad.setIdUniversidad("UNI-002");
        assertEquals("UNI-002", universidad.getIdUniversidad());
    }

    @Test
    void getNombreUniversidad() {
        assertEquals("Universidad Central", universidad.getNombreUniversidad());
        universidad.setNombreUniversidad("Universidad Nacional");
        assertEquals("Universidad Nacional", universidad.getNombreUniversidad());
    }

    @Test
    void setNombreUniversidad() {
        universidad.setNombreUniversidad("Universidad Nacional");
        assertEquals("Universidad Nacional", universidad.getNombreUniversidad());
    }

    @Test
    void getNombreRector() {
        assertEquals("Dr. Juan Gomez", universidad.getNombreRector());
        universidad.setNombreRector("Dr. Maria Lopez");
        assertEquals("Dr. Maria Lopez", universidad.getNombreRector());
    }

    @Test
    void setNombreRector() {
        universidad.setNombreRector("Dr. Maria Lopez");
        assertEquals("Dr. Maria Lopez", universidad.getNombreRector());
    }

    @Test
    void getTelefono() {
        assertEquals("1234567890", universidad.getTelefono());
        universidad.setTelefono("0987654321");
        assertEquals("0987654321", universidad.getTelefono());
    }

    @Test
    void setTelefono() {
        universidad.setTelefono("0987654321");
        assertEquals("0987654321", universidad.getTelefono());
    }

    @Test
    void gestionarUsuario() {
        universidad.gestionarUsuario();
    }

    @Test
    void gestionarReserva() {
        universidad.gestionarReserva();
    }

    @Test
    void gestionarLugar() {
        universidad.gestionarLugar();
    }

    @Test
    void gestionarEspacio() {
        universidad.gestionarEspacio();
    }
}