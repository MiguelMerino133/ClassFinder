package ec.edu.uce.classfinder.modelo;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class UsuarioTest {

    private Usuario usuario;

    @BeforeEach
    void setUp() {
        usuario = new Usuario();
    }

    @Test
    void getIdUsuario() {
        usuario.setIdUsuario("USR-002");
        assertEquals("USR-002", usuario.getIdUsuario());
    }

    @Test
    void setIdUsuario() {
        usuario.setIdUsuario("USR-002");
    }

    @Test
    void getNombre() {
        usuario.setNombre("Ana");
        assertEquals("Ana", usuario.getNombre());
    }

    @Test
    void setNombre() {
        usuario.setNombre("Ana");
    }

    @Test
    void getContrasena() {
        usuario.setContrasena("abc123");
        assertEquals("abc123", usuario.getContrasena());
    }

    @Test
    void setContrasena() {
        usuario.setContrasena("abc123");
    }

    @Test
    void getCedulaIdentidad() {
        usuario.setCedulaIdentidad("1728803247");
        assertEquals("1728803247", usuario.getCedulaIdentidad());
    }

    @Test
    void setCedulaIdentidad() {
        usuario.setCedulaIdentidad("1728803247");
    }

    @Test
    void getCorreo() {
        usuario.setCorreo("ana@gmail.com");
        assertEquals("ana@gmail.com", usuario.getCorreo());
    }

    @Test
    void setCorreo() {
        usuario.setCorreo("ana@gmail.com");
    }

    @Test
    void getRol() {
        usuario.setRol("Docente");
        assertEquals("Docente", usuario.getRol());
    }

    @Test
    void setRol() {
        usuario.setRol("Docente");
    }

    @Test
    void registrarUsuario() {
    }

    @Test
    void registrarReserva() {
    }

    @Test
    void consultarEspacio() {
    }

    @Test
    void consultarLugar() {
    }

    @Test
    void eliminarReserva() {
    }

    @Test
    void testToString() {
    }
}