package ec.edu.uce.classfinder.modelo;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class UsuarioTest {
    private Usuario usuario;

    @BeforeEach
    void setUp() {
        usuario = new Usuario("USR-001", "Miguel Merino", "miguel123", "1728803246", "miguel@gmail.com", "Estudiante");
    }

    @Test
    void getIdUsuario() {
        assertEquals("USR-001", usuario.getIdUsuario());
    }

    @Test
    void setIdUsuario() {
        usuario.setIdUsuario("USR-002");
        assertEquals("USR-002", usuario.getIdUsuario());
    }

    @Test
    void getNombre() {
        assertEquals("Miguel Merino", usuario.getNombre());
    }

    @Test
    void setNombre() {
        usuario.setNombre("Maria Lopez");
        assertEquals("Maria Lopez", usuario.getNombre());
    }

    @Test
    void getCedulaIdentidad() {
        assertEquals("1728803246", usuario.getCedulaIdentidad());
    }

    @Test
    void setCedulaIdentidad() {
        usuario.setCedulaIdentidad("0987654321");
        assertEquals("0987654321", usuario.getCedulaIdentidad());
    }

    @Test
    void getCorreo() {
        assertEquals("miguel@gmail.com", usuario.getCorreo());
    }

    @Test
    void setCorreo() {
        usuario.setCorreo("maria@gmail.com");
        assertEquals("maria@gmail.com", usuario.getCorreo());
    }

    @Test
    void getRol() {
        assertEquals("Estudiante", usuario.getRol());
    }

    @Test
    void setRol() {
        usuario.setRol("Administrador");
        assertEquals("Administrador", usuario.getRol());
    }

    @Test
    void getContrasena() {
        assertEquals("miguel123", usuario.getContrasena());
    }

    @Test
    void setContrasena() {
        usuario.setContrasena("NewPass456@");
        assertEquals("NewPass456@", usuario.getContrasena());
    }


    @Test
    void registrarUsuario() {
        usuario.registrarUsuario();
    }

    @Test
    void eliminarReserva() {
        usuario.eliminarReserva();
    }

    @Test
    void registrarReserva() {
        usuario.registrarReserva();
    }

    @Test
    void consultarEspacio() {
        usuario.consultarEspacio();
    }

    @Test
    void consultarLugar() {
        usuario.consultarLugar();
    }


}